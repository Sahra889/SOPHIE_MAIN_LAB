📘 SOPHIE Starterpaket

1. Stelle sicher, dass dein lokaler SOPHIE-Server läuft:
   > node server.js

2. Führe dann diese Datei aus:
   > start_sophie_ui.cmd

3. SOPHIE wird im Chrome-Browser geöffnet mit:
   > http://localhost:3000/manifest.html

4. Um SOPHIE automatisch zu starten:
   - Drücke Win+R
   - Tippe: shell:startup
   - Lege dort eine Verknüpfung zu `start_sophie_ui.cmd` ab

🧠 SOPHIE wird ab jetzt mit deinem PC hochgefahren.
